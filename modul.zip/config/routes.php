<?php
use Library\Route;

return  array(
    'default' => new Route('/', 'Site', 'index'),
    'index' => new Route('/index.php', 'Site', 'index'),
    'category' => new Route('/category/{id}', 'Category', 'index', array('id' => '[0-9]+')),
    'post'=> new Route('/post/{id}', 'Post', 'index', array('id' => '[0-9]+')),
    'tag'=> new Route('/tag/{id}', 'Tag', 'index', array('id' => '.+')),
    'tag_show' => new Route('/post/show/?', 'Tag', 'show'),
    'post_views_update' => new Route('/post/viewupdate/{id}', 'Post', 'update', array('id' => '[0-9_]+')),
    'category_analitics' => new Route('/analitics/?', 'Category', 'analitics'),
    'comment' => new Route('/post/comment/?', 'Post', 'comment'),
    'post_like' => new Route('/post/like/{id}', 'Post', 'like', array('id' => '[0-9]+')),
    'post_dislike' => new Route('/post/dislike/{id}', 'Post', 'dislike', array('id' => '[0-9]+')),
    'comment_change_by_id' => new Route('/post/comment/id/?', 'Post', 'change'),
    'comments_by_user_id' => new Route('/comment/{id}', 'Site', 'comment', array('id' => '[0-9]+')),
    'search' => new Route('/search/?', 'Site', 'search'),

    'login' => new Route('/login/?', 'Security', 'login'),
    'logout' => new Route('/logout/?', 'Security', 'logout'),
    'register' => new Route('/register', 'Security', 'register')

   
);