

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";






CREATE TABLE `advert` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



INSERT INTO `advert` (`id`, `name`, `price`, `company`) VALUES
(1, 'фото1', 8000, 'MTS1'),
(2, 'фото2', 3000, 'MTS2'),
(3, 'фото3', 15000, 'MTS3'),
(4, 'фото4', 400, 'MTS4'),
(5, 'фото5', 13000, 'MTS5'),
(6, 'фото6', 1500, 'MTS6'),
(7, 'фото7', 7000, 'MTS7'),
(8, 'фото8', 5000, 'MTS8');



CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



INSERT INTO `category` (`id`, `name`) VALUES
(1, 'What is Lorem Ipsum?'),
(2, 'Why do we use it?'),
(3, 'Where does it come from?'),
(4, 'Where can I get some?'),
(5, 'What is Lorem Ipsum?'),
(8, 'Where can I get some?');



CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `mark` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



INSERT INTO `comments` (`id`, `message`, `date`, `user_id`, `post_id`, `mark`, `parent_id`, `visible`) VALUES
(6, 'Опять  (((', '2017-02-11 21:26:35', 2, 79, 0, 0, 1),
(7, ' молодец', '2017-02-11 21:28:40', 3, 41, 0, 0, 1),
(55, 'очень жаль(', '2017-02-12 21:29:56', 2, 56, 1, NULL, 1),
(56, 'cool', '2017-02-12 21:31:49', 2, 9, 0, 13, 1),
(59, 'Ага', '2017-02-13 12:06:47', 4, 95, 0, 58, 1);





CREATE TABLE `menu` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `parent_id` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `menu` (`id`, `title`, `parent_id`) VALUES
(1, 'Навигация', 0),
(2, 'NewMenu', 1),
(3, 'Меню', 1),
(4, 'Меню', 1),
(6, 'Подменю', 3),
(7, 'Подменю', 3),
(8, 'Подменю2', 7),
(9, 'Подменю2', 7),
(10, 'Меню', 1);



CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `post` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `views` int(11) NOT NULL DEFAULT '0',
  `category` int(11) DEFAULT NULL,
  `analitics` int(11) NOT NULL,
  `picture` varchar(200) NOT NULL,
  `tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;





CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `activation_hash` char(32) DEFAULT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'ROLE_USER'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `user` (`id`, `email`, `password`, `activation_hash`, `role`) VALUES
(1, 'f@f.com', 'f8ac34a998c0638f1f3c8739c5158b86', NULL, 'ROLE_USER'),
(2, 'qw.com', 'f8ac34a998c0638f1f3c8739c5158b86', NULL, 'ROLE_USER');


ALTER TABLE `advert`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id_2` (`user_id`),
  ADD KEY `parent_id` (`parent_id`);


ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`);


ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `advert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

ALTER TABLE `menu`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;


ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`category`) REFERENCES `category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

