<?php

error_reporting(E_ALL);

use Library\Config;
use Library\Container;
use Library\RepositoryManager;
use Library\Request;
use Library\Session;
use Library\Router;
use Library\Cookie;
use Library\DbConnection;
use Library\MetaHelper;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Controller\ErrorController;


define('DS', DIRECTORY_SEPARATOR);
define('ROOT',  __DIR__.DS. '..'.DS );
define('SRC_DIR', ROOT . 'src' . DS);
define('VIEW_DIR', SRC_DIR.'View'.DS);
define('LIB_DIR', SRC_DIR.'Library'.DS);
define('CONFIG_DIR', ROOT . 'config' . DS);
define('VENDOR_DIR', ROOT . 'vendor' . DS);
define('LOG_DIR', ROOT . 'logs' . DS);

require VENDOR_DIR.'autoload.php';

try{
    Session::start();
    $config=new Config();
    $request = new Request();
    $pdo = (new DbConnection($config))->getPDO();
    $repositoryManager=(new RepositoryManager())
        ->setPDO($pdo);

    $router = new Router(CONFIG_DIR . 'routes.php');
    $metaHelper=new MetaHelper($config);

    
    $logger = new Logger('default_logger');
    
    $logger->pushHandler(new StreamHandler(LOG_DIR.'log.txt', Logger::DEBUG));

    $advertService=new \Model\AdvertService();

    $cookie=new Cookie();
    $container =new Container();

    $container->set('cookie', $cookie);
    $container->set('config', $config);

    $container->set('database_connection', $pdo);

    $container->set('repository_manager', $repositoryManager);

    $container->set('router', $router);
    
    $container->set('meta_helper', $metaHelper);

    $container->set('logger', $logger);
    
    $container->set('advert_service', $advertService);

    $router->match($request);

    $route = $router->getCurrentRoute();
    
    $controller = 'Controller\\' . $route->controller . 'Controller';

    $action = $route->action . 'Action';

    
    $controller = new $controller();

    $controller->setContainer($container);
    
    if(!method_exists($controller,$action)){
        throw new \Exception("Page don't found",404);
    }

    $content=$controller->$action($request);
    var_dump($content);


} catch (\Exception $e){
    $controller=new ErrorController();
    $controller->setContainer($container);    
    $content=$controller->errorAction($request,$e);
}

echo $content;



