<?php
namespace Library\Exception;


class ParameterNotFoundException extends \Exception
{

}